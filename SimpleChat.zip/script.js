// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getFirestore, collection, addDoc, query, where, orderBy, onSnapshot } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC6SHZBenztyCgvtE0zBU7edEOPLVfFVGI",
    authDomain: "wecgarts.firebaseapp.com",
    projectId: "wecgarts",
    storageBucket: "wecgarts.firebasestorage.app",
    messagingSenderId: "316267782326",
    appId: "1:316267782326:web:2c16b36561d36c4ee94617"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// DOM Elements
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-message');
const messagesContainer = document.querySelector('.messages-container');
const chatOptions = document.querySelectorAll('.option-btn');
const chatHeader = document.querySelector('.chat-header h2');

// Generate random user ID and name for testing
const userId = 'user_' + Math.random().toString(36).substr(2, 9);
const userName = 'Guest_' + Math.random().toString(36).substr(2, 4);

// Current chat room (global or direct)
let currentChat = 'global';

// Message sending function
async function sendMessage() {
    const message = messageInput.value.trim();
    if (message) {
        const timestamp = new Date();
        try {
            await addDoc(collection(db, 'messages'), {
                userId: userId,
                userName: userName,
                text: message,
                room: currentChat,
                timestamp: timestamp
            });
            messageInput.value = '';
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } catch (error) {
            console.error('Error sending message:', error);
        }
    }
}

// Listen for messages
function listenToMessages() {
    const messagesRef = collection(db, 'messages');
    const q = query(
        messagesRef,
        where('room', '==', currentChat),
        orderBy('timestamp')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
        snapshot.docChanges().forEach(change => {
            if (change.type === 'added') {
                displayMessage(change.doc.data());
            }
        });
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    });

    return unsubscribe;
}

// Display message in the UI
function displayMessage(messageData) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.classList.add(messageData.userId === userId ? 'sent' : 'received');
    
    const messageContent = document.createElement('div');
    if (messageData.userId !== userId) {
        const sender = document.createElement('small');
        sender.style.opacity = '0.7';
        sender.textContent = messageData.userName;
        messageContent.appendChild(sender);
    }
    
    const text = document.createElement('p');
    text.textContent = messageData.text;
    messageContent.appendChild(text);
    
    messageElement.appendChild(messageContent);
    messagesContainer.appendChild(messageElement);
    addMessageAnimation(messageElement);
}

// Event Listeners
sendButton.addEventListener('click', sendMessage);

messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

let unsubscribe = null;

chatOptions.forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons
        chatOptions.forEach(btn => btn.classList.remove('active'));
        // Add active class to clicked button
        button.classList.add('active');
        
        // Update current chat and header
        currentChat = button.dataset.chat;
        chatHeader.textContent = currentChat === 'global' ? 'Global Chat Room' : 'Direct Messages';
        
        // Clear messages container
        messagesContainer.innerHTML = '';
        
        // Unsubscribe from previous listener if exists
        if (unsubscribe) {
            unsubscribe();
        }
        
        // Start listening to new messages
        unsubscribe = listenToMessages();
    });
});

// Initialize message listening
unsubscribe = listenToMessages();

// Add some animations for message interactions
function addMessageAnimation(element) {
    element.style.animation = 'none';
    element.offsetHeight; // Trigger reflow
    element.style.animation = 'messageSlide 0.3s ease-out';
}

// Update online count randomly for demo purposes
function updateOnlineCount() {
    const onlineCount = document.querySelector('.online-count span');
    const count = Math.floor(Math.random() * 20) + 1;
    onlineCount.textContent = `${count} online`;
}

setInterval(updateOnlineCount, 5000);
