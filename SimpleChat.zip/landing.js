// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getFirestore, collection, query, where, getDocs, doc, setDoc, serverTimestamp, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC6SHZBenztyCgvtE0zBU7edEOPLVfFVGI",
    authDomain: "wecgarts.firebaseapp.com",
    projectId: "wecgarts",
    storageBucket: "wecgarts.firebasestorage.app",
    messagingSenderId: "316267782326",
    appId: "1:316267782326:web:2c16b36561d36c4ee94617"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// DOM Elements
const authTabs = document.querySelectorAll('.auth-tab');
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');

// Switch between login and signup forms
authTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const targetForm = tab.dataset.tab;
        
        // Update active tab
        authTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        
        // Show/hide forms
        if (targetForm === 'login') {
            loginForm.classList.remove('hidden');
            signupForm.classList.add('hidden');
        } else {
            loginForm.classList.add('hidden');
            signupForm.classList.remove('hidden');
        }
    });
});

// Handle registration
signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('signup-username').value.trim();
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('signup-confirm-password').value;

    if (username.length < 3) {
        alert('Username must be at least 3 characters long');
        return;
    }

    if (password.length < 6) {
        alert('Password must be at least 6 characters long');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }

    try {
        // Check if username already exists
        const userRef = doc(db, 'users', username);
        const userDoc = await getDoc(userRef);

        if (userDoc.exists()) {
            alert('Username already exists');
            return;
        }

        // Create new user document
        await setDoc(userRef, {
            username: username,
            password: password, 
            contacts: [],
            avatarStyle: 'avataaars',
            createdAt: serverTimestamp(),
            online: true
        });

        // Store username in localStorage
        localStorage.setItem('username', username);
        
        // Redirect to chat
        window.location.href = 'chat.html';
    } catch (error) {
        console.error('Error during registration:', error);
        alert('Registration failed. Please try again.');
    }
});

// Handle login
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;

    try {
        // Get user document
        const userRef = doc(db, 'users', username);
        const userDoc = await getDoc(userRef);

        if (!userDoc.exists()) {
            alert('Username not found');
            return;
        }

        const userData = userDoc.data();
        if (userData.password !== password) {
            alert('Incorrect password');
            return;
        }

        // Update online status
        await setDoc(userRef, {
            online: true
        }, { merge: true });

        // Store username in localStorage
        localStorage.setItem('username', username);
        
        // Redirect to chat
        window.location.href = 'chat.html';
    } catch (error) {
        console.error('Error during login:', error);
        alert('Login failed. Please try again.');
    }
});
