import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getFirestore, collection, addDoc, query, where, onSnapshot, getDocs, updateDoc, doc, deleteDoc, serverTimestamp, getDoc, setDoc, orderBy } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAjbxLqHPbYzaC7sJ2mQWqHZZi8zxD6D_k",
    authDomain: "wecgarts.firebaseapp.com",
    projectId: "wecgarts",
    storageBucket: "wecgarts.appspot.com",
    messagingSenderId: "1075600181792",
    appId: "1:1075600181792:web:e0f4a6e0c7d12a89c8c2a1",
    measurementId: "G-M6YGVR5X7S"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Check if user is logged in
const username = localStorage.getItem('username');
if (!username) {
    window.location.href = 'index.html';
}

// Initialize UI elements
document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const globalChat = document.getElementById('global-chat');
    const directChat = document.getElementById('direct-chat');
    const directChatContainer = document.querySelector('.direct-chat-container');
    const messagesContainer = document.querySelector('#global-chat .messages-container');
    const directMessagesContainer = document.querySelector('#direct-chat .messages-container');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message');
    const contactInput = document.getElementById('contact-input');
    const addContactBtn = document.getElementById('add-contact-btn');
    const backBtn = document.querySelector('.back-btn');
    const chatOptions = document.querySelectorAll('.option-btn');
    const currentUsername = document.getElementById('current-username');
    const userAvatar = document.querySelector('.avatar img');

    // Set current username
    currentUsername.textContent = username;

    // Initialize chat state
    let currentChat = 'global';
    let currentContact = null;
    let globalChatUnsubscribe = null;
    let directChatUnsubscribe = null;

    // Chat toggle
    document.querySelectorAll('.option-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // Update active state
            document.querySelectorAll('.option-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const chatType = btn.getAttribute('data-chat');
            currentChat = chatType;
            
            if (chatType === 'global') {
                // Show global chat
                globalChat.classList.remove('hidden');
                directChat.classList.add('hidden');
                loadGlobalChat();
            } else {
                // Show direct messages
                globalChat.classList.add('hidden');
                directChat.classList.remove('hidden');
                document.querySelector('.chat-header h2').textContent = 'Direct Messages';
                document.querySelector('.add-contact-container').classList.remove('hidden');
                directChatContainer.classList.add('hidden');
                backBtn.classList.add('hidden');
                loadContacts();
            }
        });
    });

    // Send message handlers
    if (sendButton) {
        sendButton.addEventListener('click', sendMessage);
    }
    if (messageInput) {
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }

    // Direct message handlers
    const sendDirectMessageBtn = document.getElementById('send-direct-message');
    const directMessageInput = document.getElementById('direct-message-input');

    if (sendDirectMessageBtn) {
        sendDirectMessageBtn.addEventListener('click', sendDirectMessage);
    }
    if (directMessageInput) {
        directMessageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendDirectMessage();
            }
        });
    }

    // Contact handlers
    if (addContactBtn) {
        addContactBtn.addEventListener('click', () => {
            const contact = contactInput.value.trim();
            if (contact) {
                addContact(contact);
                contactInput.value = '';
            }
        });
    }
    if (contactInput) {
        contactInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const contact = contactInput.value.trim();
                if (contact) {
                    addContact(contact);
                    contactInput.value = '';
                }
            }
        });
    }

    // Add click handler for user's avatar
    if (userAvatar) {
        userAvatar.style.cursor = 'pointer';
        userAvatar.addEventListener('click', () => {
            window.location.href = 'avatar.html';
        });
    }

    // Update avatar display
    async function updateUserAvatar() {
        try {
            const userDoc = await getDoc(doc(db, 'users', username));
            const avatarStyle = userDoc.data()?.avatarStyle || 'avataaars';
            if (userAvatar) {
                userAvatar.src = `https://api.dicebear.com/6.x/${avatarStyle}/svg?seed=${username}`;
            }
        } catch (error) {
            console.error('Error updating avatar:', error);
        }
    }

    // Listen for avatar changes
    const userRef = doc(db, 'users', username);
    onSnapshot(userRef, (doc) => {
        if (doc.exists()) {
            updateUserAvatar();
        }
    });

    // Global Chat Functions
    async function sendMessage() {
        const message = messageInput.value.trim();
        if (message) {
            try {
                await addDoc(collection(db, 'messages'), {
                    text: message,
                    username: username,
                    timestamp: serverTimestamp()
                });
                messageInput.value = '';
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            } catch (error) {
                console.error('Error sending message:', error);
                alert('Failed to send message. Please try again.');
            }
        }
    }

    async function loadGlobalChat() {
        // Clear any existing messages
        messagesContainer.innerHTML = '';
        
        // Unsubscribe from any existing listeners
        if (globalChatUnsubscribe) {
            globalChatUnsubscribe();
            globalChatUnsubscribe = null;
        }
        if (directChatUnsubscribe) {
            directChatUnsubscribe();
            directChatUnsubscribe = null;
        }

        currentChat = 'global';
        
        // Set up new listener
        const q = query(collection(db, 'messages'), orderBy('timestamp', 'asc'));
        globalChatUnsubscribe = onSnapshot(q, (snapshot) => {
            snapshot.docChanges().forEach((change) => {
                const messageData = { ...change.doc.data(), id: change.doc.id };
                
                if (change.type === 'added') {
                    displayMessage(messageData, messagesContainer);
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                } else if (change.type === 'modified') {
                    const messageElement = document.querySelector(`[data-message-id="${messageData.id}"]`);
                    if (messageElement) {
                        messageElement.remove();
                        displayMessage(messageData, messagesContainer);
                    }
                } else if (change.type === 'removed') {
                    const messageElement = document.querySelector(`[data-message-id="${messageData.id}"]`);
                    if (messageElement) {
                        messageElement.remove();
                    }
                }
            });
        });
    }

    // Direct Message Functions
    async function addContact(contactUsername) {
        try {
            if (contactUsername === username) {
                alert("You can't add yourself as a contact");
                return;
            }

            // Check if contact exists
            const contactRef = doc(db, 'users', contactUsername);
            const contactDoc = await getDoc(contactRef);
            
            if (!contactDoc.exists()) {
                alert('User not found');
                return;
            }

            // Get current user's document
            const userRef = doc(db, 'users', username);
            const userDoc = await getDoc(userRef);
            
            if (!userDoc.exists()) {
                console.error('User document not found');
                return;
            }

            const contacts = userDoc.data().contacts || [];
            
            // Check if contact is already added
            if (contacts.includes(contactUsername)) {
                alert('Contact already added');
                return;
            }

            // Add contact
            contacts.push(contactUsername);
            await updateDoc(userRef, { contacts });

            // Reload contacts list
            loadContacts();
            
            alert('Contact added successfully');
        } catch (error) {
            console.error('Error adding contact:', error);
            alert('Failed to add contact');
        }
    }

    async function loadContacts() {
        try {
            const userRef = doc(db, 'users', username);
            const userDoc = await getDoc(userRef);
            
            if (!userDoc.exists()) {
                console.error('User document not found');
                return;
            }

            const contacts = userDoc.data().contacts || [];
            const contactsGrid = document.querySelector('.contacts-grid');
            contactsGrid.innerHTML = '';

            // Fetch all users to get their avatar styles
            const usersSnapshot = await getDocs(collection(db, 'users'));
            const userAvatars = {};
            usersSnapshot.forEach(doc => {
                userAvatars[doc.id] = doc.data().avatarStyle || 'avataaars';
            });

            // Display each contact
            for (const contactUsername of contacts) {
                const contactCard = document.createElement('div');
                contactCard.className = 'contact-card';
                
                const avatarStyle = userAvatars[contactUsername] || 'avataaars';
                contactCard.innerHTML = `
                    <div class="contact-avatar">
                        <img src="https://api.dicebear.com/6.x/${avatarStyle}/svg?seed=${contactUsername}" alt="${contactUsername}'s avatar">
                    </div>
                    <div class="contact-info">
                        <h3>${contactUsername}</h3>
                    </div>
                `;
                
                contactCard.addEventListener('click', () => loadDirectChat(contactUsername));
                contactsGrid.appendChild(contactCard);
            }
        } catch (error) {
            console.error('Error loading contacts:', error);
        }
    }

    async function loadDirectChat(contactUsername) {
        // Update UI
        currentChat = 'direct';
        currentContact = contactUsername;
        document.querySelector('.chat-header h2').textContent = `Chat with ${contactUsername}`;
        document.querySelector('.add-contact-container').classList.add('hidden');
        document.querySelector('.direct-chat-container').classList.remove('hidden');
        document.querySelector('.back-btn').classList.remove('hidden');

        // Clear any existing messages
        const directMessagesContainer = document.querySelector('.direct-chat-container .messages-container');
        directMessagesContainer.innerHTML = '';
        
        // Unsubscribe from any existing listeners
        if (directChatUnsubscribe) {
            directChatUnsubscribe();
            directChatUnsubscribe = null;
        }
        if (globalChatUnsubscribe) {
            globalChatUnsubscribe();
            globalChatUnsubscribe = null;
        }
        
        // Create a unique chat ID (alphabetically sorted usernames)
        const chatId = [username, contactUsername].sort().join('_');
        
        try {
            // Set up new listener with simplified query
            const q = query(
                collection(db, 'direct_messages'),
                where('chatId', '==', chatId),
                orderBy('timestamp')
            );
            
            directChatUnsubscribe = onSnapshot(q, (snapshot) => {
                snapshot.docChanges().forEach((change) => {
                    const messageData = { ...change.doc.data(), id: change.doc.id };
                    
                    if (change.type === 'added') {
                        displayMessage(messageData, directMessagesContainer);
                        directMessagesContainer.scrollTop = directMessagesContainer.scrollHeight;
                    } else if (change.type === 'modified') {
                        const messageElement = document.querySelector(`[data-message-id="${messageData.id}"]`);
                        if (messageElement) {
                            messageElement.remove();
                            displayMessage(messageData, directMessagesContainer);
                        }
                    } else if (change.type === 'removed') {
                        const messageElement = document.querySelector(`[data-message-id="${messageData.id}"]`);
                        if (messageElement) {
                            messageElement.remove();
                        }
                    }
                });
            });
        } catch (error) {
            console.error('Error loading direct chat:', error);
            alert('Failed to load chat messages. Please try again.');
        }
    }

    // Function to display a message
    function displayMessage(messageData, container) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');
        messageElement.dataset.messageId = messageData.id;
        
        const isOwnMessage = messageData.sender === username || messageData.username === username;
        messageElement.classList.add(isOwnMessage ? 'sent' : 'received');
        
        const time = messageData.timestamp ? 
            new Date(messageData.timestamp.toDate()).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            }) : '';
        
        const sender = messageData.sender || messageData.username;
        
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        
        // Add sender name for received messages
        if (!isOwnMessage) {
            const senderElement = document.createElement('div');
            senderElement.classList.add('sender');
            senderElement.textContent = sender;
            messageContent.appendChild(senderElement);
        }
        
        // Add message text
        const textElement = document.createElement('p');
        textElement.classList.add('text');
        textElement.textContent = messageData.text;
        messageContent.appendChild(textElement);
        
        // Add time
        const timeElement = document.createElement('div');
        timeElement.classList.add('time');
        timeElement.textContent = time;
        messageContent.appendChild(timeElement);
        
        // Add edit/delete options for own messages
        if (isOwnMessage) {
            const options = document.createElement('div');
            options.classList.add('message-options');
            options.innerHTML = `
                <button class="edit-btn" title="Edit">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="delete-btn" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            
            // Add event listeners for edit and delete
            const editBtn = options.querySelector('.edit-btn');
            const deleteBtn = options.querySelector('.delete-btn');
            
            editBtn.addEventListener('click', () => startEditing(messageElement, messageData));
            deleteBtn.addEventListener('click', () => deleteMessage(messageData));
            
            messageContent.appendChild(options);
        }
        
        messageElement.appendChild(messageContent);
        container.appendChild(messageElement);
        
        // Add hover effect
        messageElement.addEventListener('mouseenter', () => {
            if (isOwnMessage) {
                const options = messageElement.querySelector('.message-options');
                if (options) options.style.display = 'flex';
            }
        });
        
        messageElement.addEventListener('mouseleave', () => {
            if (isOwnMessage) {
                const options = messageElement.querySelector('.message-options');
                if (options) options.style.display = 'none';
            }
        });
    }

    // Function to start editing a message
    function startEditing(messageElement, messageData) {
        const messageContent = messageElement.querySelector('.message-content');
        const originalText = messageData.text;
        
        // Create edit input
        messageElement.classList.add('editing');
        const textElement = messageContent.querySelector('.text');
        const originalContent = messageContent.innerHTML;
        
        textElement.innerHTML = `
            <input type="text" class="edit-input" value="${originalText}">
            <div class="edit-actions">
                <button class="save-edit">Save</button>
                <button class="cancel-edit">Cancel</button>
            </div>
        `;
        
        const input = textElement.querySelector('.edit-input');
        const saveBtn = textElement.querySelector('.save-edit');
        const cancelBtn = textElement.querySelector('.cancel-edit');
        
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
        
        saveBtn.addEventListener('click', async () => {
            const newText = input.value.trim();
            if (newText && newText !== originalText) {
                await updateMessage(messageData.id, newText);
            }
            messageContent.innerHTML = originalContent;
            messageElement.classList.remove('editing');
        });
        
        cancelBtn.addEventListener('click', () => {
            messageContent.innerHTML = originalContent;
            messageElement.classList.remove('editing');
        });
        
        input.addEventListener('keypress', async (e) => {
            if (e.key === 'Enter') {
                const newText = input.value.trim();
                if (newText && newText !== originalText) {
                    await updateMessage(messageData.id, newText);
                }
                messageContent.innerHTML = originalContent;
                messageElement.classList.remove('editing');
            }
        });
    }

    // Function to update a message
    async function updateMessage(messageId, newText) {
        try {
            const messageRef = doc(db, currentChat === 'global' ? 'messages' : 'direct_messages', messageId);
            await updateDoc(messageRef, {
                text: newText,
                edited: true,
                editedAt: serverTimestamp()
            });
        } catch (error) {
            console.error('Error updating message:', error);
            alert('Failed to update message');
        }
    }

    // Function to delete a message
    async function deleteMessage(messageData) {
        if (confirm('Are you sure you want to delete this message?')) {
            try {
                const messageRef = doc(db, currentChat === 'global' ? 'messages' : 'direct_messages', messageData.id);
                await deleteDoc(messageRef);
            } catch (error) {
                console.error('Error deleting message:', error);
                alert('Failed to delete message');
            }
        }
    }

    // Back button functionality
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            document.querySelector('.add-contact-container').classList.remove('hidden');
            document.querySelector('.direct-chat-container').classList.add('hidden');
            backBtn.classList.add('hidden');
            currentContact = null;
            
            // Unsubscribe from direct chat
            if (directChatUnsubscribe) {
                directChatUnsubscribe();
                directChatUnsubscribe = null;
            }
            
            // Clear messages
            const directMessagesContainer = document.querySelector('.direct-chat-container .messages-container');
            directMessagesContainer.innerHTML = '';
            
            // Reset header
            document.querySelector('.chat-header h2').textContent = 'Direct Messages';
        });
    }

    async function sendDirectMessage() {
        const message = directMessageInput.value.trim();
        if (message && currentContact) {
            try {
                const chatId = [username, currentContact].sort().join('_');
                await addDoc(collection(db, 'direct_messages'), {
                    sender: username,
                    receiver: currentContact,
                    chatId: chatId,
                    text: message,
                    timestamp: serverTimestamp()
                });
                directMessageInput.value = '';
            } catch (error) {
                console.error('Error sending direct message:', error);
                alert('Failed to send message. Please try again.');
            }
        }
    }

    // Utility Functions
    async function saveEdit(messageData, newText) {
        if (newText.trim() === messageData.text) {
            cancelEdit(document.querySelector(`[data-message-id="${messageData.id}"]`), messageData);
            return;
        }
        
        try {
            const messageRef = doc(db, currentChat === 'global' ? 'messages' : 'direct_messages', messageData.id);
            await updateDoc(messageRef, {
                text: newText.trim(),
                edited: true,
                editedAt: new Date()
            });
        } catch (error) {
            console.error('Error updating message:', error);
            alert('Failed to update message');
        }
    }

    function cancelEdit(messageElement, messageData) {
        const messageContent = messageElement.querySelector('.message-content');
        messageElement.classList.remove('editing');
        messageContent.innerHTML = `
            ${messageData.username !== username ? `<small class="sender-name">${messageData.username}</small>` : ''}
            <p>${messageData.text}</p>
            ${messageData.edited ? '<div class="edited-indicator">(edited)</div>' : ''}
            <small class="message-time">${new Intl.DateTimeFormat('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            }).format(messageData.timestamp.toDate())}</small>
        `;
    }

    async function deleteMessage(messageData) {
        if (!confirm('Are you sure you want to delete this message?')) {
            return;
        }
        
        try {
            const messageRef = doc(db, currentChat === 'global' ? 'messages' : 'direct_messages', messageData.id);
            await deleteDoc(messageRef);
        } catch (error) {
            console.error('Error deleting message:', error);
            alert('Failed to delete message');
        }
    }

    function addMessageAnimation(element) {
        element.style.animation = 'none';
        element.offsetHeight; // Trigger reflow
        element.style.animation = 'messageSlide 0.3s ease-out';
    }

    // Handle online status
    async function updateOnlineStatus(status) {
        try {
            const userRef = doc(db, 'users', username);
            await setDoc(userRef, { online: status }, { merge: true });
        } catch (error) {
            console.error('Error updating online status:', error);
        }
    }

    // Update online status when window loads/unloads
    window.addEventListener('load', () => updateOnlineStatus(true));
    window.addEventListener('beforeunload', () => updateOnlineStatus(false));

    // Listen to online users
    function listenToOnlineUsers() {
        const q = query(collection(db, 'users'), where('online', '==', true));
        return onSnapshot(q, (snapshot) => {
            const onlineCount = snapshot.size;
            const onlineCountElement = document.querySelector('.online-count span');
            if (onlineCountElement) {
                onlineCountElement.textContent = `${onlineCount} online`;
            }
        }, (error) => {
            console.error('Error listening to online users:', error);
        });
    }

    // Initialize
    loadGlobalChat();
    listenToOnlineUsers();
});
