import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getFirestore, doc, updateDoc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC6SHZBenztyCgvtE0zBU7edEOPLVfFVGI",
    authDomain: "wecgarts.firebaseapp.com",
    projectId: "wecgarts",
    storageBucket: "wecgarts.firebasestorage.app",
    messagingSenderId: "316267782326",
    appId: "1:316267782326:web:2c16b36561d36c4ee94617"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Check if user is logged in
const username = localStorage.getItem('username');
if (!username) {
    window.location.href = 'index.html';
}

let selectedAvatar = null;

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const userRef = doc(db, 'users', username);
        const userDoc = await getDoc(userRef);
        
        // If user document doesn't exist, create it
        if (!userDoc.exists()) {
            await setDoc(userRef, {
                username: username,
                avatarStyle: 'avataaars',
                contacts: [],
                createdAt: serverTimestamp()
            });
        }
        
        const currentAvatarStyle = userDoc.exists() ? userDoc.data()?.avatarStyle || 'avataaars' : 'avataaars';
        selectedAvatar = currentAvatarStyle;

        // Set current avatar
        const currentAvatarImg = document.getElementById('current-avatar');
        currentAvatarImg.src = `https://api.dicebear.com/6.x/${currentAvatarStyle}/svg?seed=${username}`;

        // Generate avatar options
        const avatarGrid = document.getElementById('avatar-grid');
        const avatarStyles = [
            'adventurer', 'adventurer-neutral', 'avataaars', 'big-ears',
            'big-ears-neutral', 'big-smile', 'bottts', 'croodles',
            'croodles-neutral', 'fun-emoji', 'icons', 'identicon',
            'initials', 'lorelei', 'lorelei-neutral', 'micah',
            'miniavs', 'open-peeps', 'personas', 'pixel-art',
            'pixel-art-neutral', 'shapes', 'thumbs', 'beam',
            'bottts-neutral', 'characters', 'circles', 'diamonds',
            'gridy', 'human', 'identicon-5', 'initials-2',
            'jdenticon', 'marble', 'masks', 'notionists',
            'notionists-neutral', 'rings', 'squares', 'sunset',
            'symbols', 'thumbs-2', 'treasure', 'vibrant',
            'vintage', 'wavatar', 'bauhaus', 'pixel-art-2',
            'pixel-art-3', 'identicon-2', 'bottts-2', 'avataaars-2'
        ];
        avatarStyles.forEach(style => {
            const avatarOption = document.createElement('div');
            avatarOption.className = 'avatar-option';
            if (style === currentAvatarStyle) {
                avatarOption.classList.add('selected');
            }

            const img = document.createElement('img');
            img.src = `https://api.dicebear.com/6.x/${style}/svg?seed=${username}`;
            img.alt = style;

            avatarOption.appendChild(img);
            avatarOption.onclick = () => selectAvatar(style, avatarOption);
            avatarGrid.appendChild(avatarOption);
        });
    } catch (error) {
        console.error('Error initializing avatar page:', error);
        alert('Failed to load avatar options. Please try again.');
    }
});

// Select avatar
function selectAvatar(style, element) {
    // Remove previous selection
    document.querySelector('.avatar-option.selected')?.classList.remove('selected');
    
    // Update selection
    element.classList.add('selected');
    selectedAvatar = style;
    
    // Update preview
    document.getElementById('current-avatar').src = `https://api.dicebear.com/6.x/${style}/svg?seed=${username}`;
}

// Save avatar changes
window.saveAvatar = async () => {
    if (!selectedAvatar) return;

    try {
        const userRef = doc(db, 'users', username);
        await updateDoc(userRef, {
            avatarStyle: selectedAvatar
        });

        // Update avatar in localStorage
        localStorage.setItem('avatarStyle', selectedAvatar);

        // Redirect back to chat
        window.location.href = 'chat.html';
    } catch (error) {
        console.error('Error saving avatar:', error);
        alert('Failed to save avatar changes. Please try again.');
    }
};
